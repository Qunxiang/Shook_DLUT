#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>
#include <stdio.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
//后加的为了显示使用的头文件
#include<string.h>
#include "std_msgs/String.h"
#include <sstream>
using namespace std;
using namespace cv;

//Mat imageresize;
//int time_flag;
int fly_signal = 100;	//default is doing nothing
char path[100];

void imageCallback(const sensor_msgs::ImageConstPtr& msg)
{
	try
	{
		//resize(cv_bridge::toCvShare(msg, "bgr8")->image,imageresize,cvSize(640,480),0,0,CV_INTER_LINEAR);
		imshow("camera", cv_bridge::toCvShare(msg, "bgr8")->image);
		cout<<"width and height are: "<<(cv_bridge::toCvShare(msg, "bgr8")->image).cols<<" "
		<<(cv_bridge::toCvShare(msg, "bgr8")->image).rows<<endl;
		waitKey(10);
		//printf("nice\n");

		//sprintf(path, "/home/wang/bagfiles/dji/dji_image/%d.jpg", fly_signal);
		//imwrite(path, cv_bridge::toCvShare(msg, "bgr8")->image);
		fly_signal ++;
	}
	catch (cv_bridge::Exception& e)
	{
		ROS_ERROR("Could not convert from '%s' to 'bgr8'.", msg->encoding.c_str());
	}
}

int main(int argc, char** argv)
{	
	ros::init(argc, argv, "fly_signal_uav");
	ros::NodeHandle n;
	image_transport::ImageTransport it(n);

	//image_transport::Subscriber sub = it.subscribe("/usb_cam/image_raw", 1, imageCallback);
	image_transport::Subscriber sub = it.subscribe("/tag_detections_image", 1, imageCallback);		
	//从摄像头camera/image_raw节点订阅图像        /*/dji_sdk/image_raw*/

	ros::Publisher chatter_pub = n.advertise<std_msgs::String>("/uav/fly/signal", 1000);

	ros::Rate loop_rate(10);

	while(ros::ok() /*&& time_flag < 1*/)	//just run one time
	{
		std_msgs::String msg;
		std::stringstream ss;
	    ss << "hello world " << fly_signal;
	    msg.data = ss.str();
	    //ROS_INFO("%s", msg.data.c_str());

		chatter_pub.publish(msg);

		ros::spinOnce();

		loop_rate.sleep();
	}	

	return 0;
}
