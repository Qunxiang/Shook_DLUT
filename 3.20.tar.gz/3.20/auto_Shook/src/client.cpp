#include "client.h"

djiClient::djiClient()
{
}

djiClient::~djiClient()
{
}

void djiClient::Display_Main_Menu()
{
    printf("\r\n");
    printf("----------- < Main menu > ----------\r\n\r\n");
    printf("[a] Request to obtain control\n");
    printf("[b] Release control\n");
    printf("[c] Takeoff\n");
    printf("[d] Landing\n");
    printf("[e] Go home\n");
    printf("[f] Gimbal control sample\n");
    printf("[g] gimbal return\n");

    //wang
    printf("[h] 1 0 \n");
    
    printf("[p] 1 -7 \n");
    printf("[q] 1 -14 \n");
    printf("[r] 1 -21 \n");
    printf("[s] 1 -28 \n");

    printf("[t] 1 7 \n");
    printf("[u] 1 14 \n");
    printf("[v] 1 21 \n");
    printf("[w] 1 28 \n");

    printf("[x] Autonomous flight\n");

    printf("[z] Exit\n");
    printf("\ninput a/b/c etc..then press enter key\r\n");
    printf("\nuse `rostopic echo` to query drone status\r\n");
    printf("----------------------------------------\r\n");
    printf("input: ");
}

//四个参数
//前后(m) 左右(m) 上升下降(m) 偏航角(degrees)
void djiClient::tagFollow(DJIDrone* drone, float yaw, float d_x, float d_y, int degree)
{
    cout << "roatate_thea: " << degree << endl;
    //degree is less than 40!!!! 一次最多打40度的角
    float yaw_position_thea = yaw + degree;
    //cout<<"yaw_position_thea: "<<yaw_position_thea<<endl;
    
    //由于偏航角不能超过+-180，所以遇到这种情况时候需要做个小调整
    if(yaw_position_thea > 180)
    {
        yaw_position_thea -= 360;
    }
    if(yaw_position_thea < -180)
    {
        yaw_position_thea += 360;
    }
    
    //这里的角度是弧度制
    float move_x = sqrt(d_x * d_x + d_y * d_y) * cos(yaw_position_thea*3.141592654/180.0);
    float move_y = sqrt(d_x * d_x + d_y * d_y) * sin(yaw_position_thea*3.141592654/180.0);
    
    
    
    for(int i = 0; i < 30; i++)
    {
        drone->attitude_control(HORIZ_POS|VERT_VEL|YAW_ANG|HORIZ_BODY|YAW_BODY, move_x, move_y, 0, yaw_position_thea);
        usleep(20000);
    }
    usleep(500000);     //very important!!!
}

void djiClient::tagFollowSpeed(DJIDrone* drone, int speed, float yaw, int degree)
{
    //degree is less than 40!!!! 一条语句一次最多打40度的角

    cout << "roatate_thea: " << degree << endl;
    //degree is less than 40!!!!
    float yaw_position_thea = yaw + degree;
    //cout<<"yaw_position_thea: "<<yaw_position_thea<<endl;
    
    //由于偏航角不能超过+-180，所以遇到这种情况时候需要做个小调整
    if(yaw_position_thea > 180)
    {
        yaw_position_thea -= 360;
    }
    if(yaw_position_thea < -180)
    {
        yaw_position_thea += 360;
    }
    
    //这里的角度是弧度制
    float v_x = speed * cos(yaw_position_thea * 3.141592654/180.0);
    float v_y = speed * sin(yaw_position_thea * 3.141592654/180.0);
    
    for(int i = 0; i < 80; i++)
    {
        drone->velocity_control(1, v_x, v_y, 0, yaw_position_thea);
        usleep(20000);
    }
    
    //usleep(500000);     //very important!!!
}






























