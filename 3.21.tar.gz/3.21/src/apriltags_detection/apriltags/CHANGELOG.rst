^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package apriltags
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2014-11-14)
------------------
* Updated author and website
* Contributors: Mitchell Wills

0.1.0 (2014-11-08)
------------------
* Updated dependancies for indigo
* Contributors: Mitchell Wills

0.0.3 (2014-11-08)
------------------
* Added info to package.xml
* Added libv4l-dev as a dependancy
* Contributors: Mitchell Wills

0.0.2 (2014-10-31)
------------------
* Did some small cleanup and renaming to topics
  Added the package ros wiki urls
  Added example launch file
* Contributors: Mitchell Wills

0.0.1 (2014-10-27)
------------------
* Initial Commit from release r30 in https://svn.csail.mit.edu/apriltags
