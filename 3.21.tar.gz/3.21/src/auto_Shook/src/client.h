#include <ros/ros.h>
#include "std_msgs/String.h"
#include <dji_sdk/dji_drone.h>
#include <cstdlib>
#include <actionlib/client/simple_action_client.h>
#include <actionlib/client/terminal_state.h>

#include <iostream>

using namespace std;
//using namespace cv;

class djiClient
{
public:
	djiClient();
	~djiClient();

	void Display_Main_Menu();
	
	void tagFollow(DJIDrone* drone, float yaw, float d_x, float d_y, int degree);
	
	void tagFollowSpeed(DJIDrone* drone, int speed, float yaw, int degree);

};
