#include "client.h"
#include "stdlib.h"
#include "math.h"

#include <dji_sdk_demo/AprilTagDetection.h>
#include <dji_sdk_demo/AprilTagDetectionArray.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseArray.h>

#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <nav_msgs/Odometry.h>

#define TEST_UAV

int fly_follow_degree = 0;    //搜索到AprilTags后的打角
float tags_position_x = 0.0;
float tags_position_y = 0.0;
bool tags_flag = 0;

float yaw = 0.0;                //当前时刻的偏航角
int countNum = 0;

//
//int test_count_time = 1000;

void tagsInfoCallback(const dji_sdk_demo::AprilTagDetectionArray msg_position_xyz)
{
    tags_flag = 1;  //代表收到了数据，可以用于控制飞机
    //msg_position_xyz.detections[0].id;        //AprilTags编号
    //msg_position_xyz.detections[0].size;
        
    //用于计算搜索到AprilTags后的打角
     tags_position_x = msg_position_xyz.detections[0].pose.pose.position.x;
     tags_position_y = (-1) * msg_position_xyz.detections[0].pose.pose.position.y;
     //float position_z = msg_position_xyz.detections[0].pose.pose.position.z;   //暂时不考虑高度
     
     //机头为前进方向, 图像上，上面为y方向，对于飞机，向上为 x 方向
     if (tags_position_y > 0) 
     {
        fly_follow_degree = atan(tags_position_x / (tags_position_y * 1.0)) * 180.0 / 3.141592654;
     }
     else if (tags_position_y < 0)
     {
        fly_follow_degree = 180 + atan(tags_position_y / (tags_position_x * 1.0)) * 180.0 / 3.141592654;
     }
     else
     {
        fly_follow_degree = 0;
     }  

}

void yawCallback(const nav_msgs::Odometry& msg_pose_xyzw)
{
    //用于获得当前时刻的偏航角
     float yaw_x = msg_pose_xyzw.pose.pose.orientation.x;
     float yaw_y = msg_pose_xyzw.pose.pose.orientation.y;
     float yaw_z = msg_pose_xyzw.pose.pose.orientation.z;
     float yaw_w = msg_pose_xyzw.pose.pose.orientation.w;

     yaw = atan2(2*(yaw_w*yaw_z + yaw_x*yaw_y), 1-2*(yaw_y*yaw_y + yaw_z*yaw_z));
     yaw *= (180/3.141592654);
     //cout<<"yaw: "<<yaw<<endl;
}
 
int main(int argc, char **argv)
{
    djiClient uavClient;

    int main_operate_code = 0;
    int temp32;
    bool valid_flag = false;
    bool err_flag = false;
    ros::init(argc, argv, "sdk_client");
    ROS_INFO("sdk_service_client_test");
    ros::NodeHandle nh;
    DJIDrone* drone = new DJIDrone(nh);

    dji_sdk::WaypointList newWaypointList;
    dji_sdk::Waypoint waypoint0;
    dji_sdk::Waypoint waypoint1;
    dji_sdk::Waypoint waypoint2;
    dji_sdk::Waypoint waypoint3;
    dji_sdk::Waypoint waypoint4;
    
    //show a menu to cmd the uav
    uavClient.Display_Main_Menu();

    ros::Subscriber sub = nh.subscribe("/tag_detections", 1000, tagsInfoCallback);

    ros::Subscriber sub_yaw = nh.subscribe("/dji_sdk/odometry", 1000, yawCallback);

#ifdef TEST_UAV
    while(1)
    {
        //cout<<"yaw: "<<yaw<<endl;
    
    	ros::spinOnce();
    	temp32 = getchar();

    	if(temp32 != 10)
        {
            if(temp32 >= 'a' && temp32 <= 'z' && valid_flag == false)
            {
                main_operate_code = temp32;
                valid_flag = true;
            }
            else
            {
                err_flag = true;
            }
            continue;
        }
        else
        {
            if(err_flag == true)
            {
                printf("input: ERROR\n");
                uavClient.Display_Main_Menu();
                err_flag = valid_flag = false;
                continue;
            }
        }
        
        
        switch(main_operate_code)
        {
        	case 'a':
                /* request control ability*/
                drone->request_sdk_permission_control();
                break;
            case 'b':
                /* release control ability*/
                drone->release_sdk_permission_control();
                break;
            case 'c':
                /* take off */
                drone->takeoff();
                break;
            case 'd':
                /* landing*/
                drone->landing();
                break;
            case 'e':
                /* go home*/
                drone->gohome();
                break;

            case 'f':
                /* Local Navi Test */
                drone->local_position_navigation_send_request(1, 0.5, 10);
                break;

	        case 'g':
                /* GPS Navi Test */
                drone->global_position_navigation_send_request(38.88, 121.52, 10);
                break;

            /*
             *wang
             *
             *auto move test
             */    
    case 'h':
    {
        ros::Rate loop_rate2(0.25);        //rate: 1
    
        /*velocity control test*/
        cout << "velocity control test" << endl;

        /* request control ability*/
        drone->request_sdk_permission_control();
        sleep(2);
        
        //control the camera downward 
        drone->gimbal_angle_control(0, -900, 0, 20);
        sleep(2);         
                
                
        while(ros::ok())
        {   //当相对距离为小于1.5米时，不执行。
            if (tags_flag && (sqrt(tags_position_x * tags_position_x + tags_position_y * tags_position_y) > 1.0))
            {
                /*
                float yaw_final = yaw + fly_follow_degree;
                //由于偏航角不能超过+-180，所以遇到这种情况时候需要做个小调整
                if(yaw_final > 180)
                {
                    yaw_final -= 360;
                }
                if(yaw_final < -180)
                {
                    yaw_final += 360;
                }
                cout << yaw_final << endl;
                
                drone->velocity_control(1, 1.0 * cos(yaw_final*3.141592654/180.0), 1.0 * sin(yaw_final*3.141592654/180.0), 0, yaw_final);
                usleep(20000);
                */
                
                uavClient.tagFollowSpeed(drone, 1, yaw, fly_follow_degree);
                usleep(20000);
                
                tags_flag = 0;
            }
                    
            ros::spinOnce();                    
            loop_rate2.sleep();
        }
            usleep(500000);

            break;   
    }                                         

            case 'z':
                return 0;

            default:
                break;
        }

        main_operate_code = -1;
        err_flag = valid_flag = false;
        uavClient.Display_Main_Menu();
    }

#else
    //auto flight

    uavClient.Display_Main_Menu();

    temp32 = getchar();
    if(temp32 != 10)
    {
        if(temp32 >= 'a' && temp32 <= 'z' && valid_flag == false)
        {
            main_operate_code = temp32;
            valid_flag = true;
        }
        else
        {
            err_flag = true;
        }
    }
    else
    {
        if(err_flag == true)
        {
            printf("input: ERROR\n");
            uavClient.Display_Main_Menu();
            err_flag = valid_flag = false;
        }
    }

    ros::Rate loop_rate(0.25);        //rate: 1

    if (temp32 == 'x')
    {
        /* request control ability*/
        drone->request_sdk_permission_control();
        sleep(2);

        //first, auto takeoff  
        /*
        drone->takeoff();
        sleep(2);
        */
        /*
        for(int i = 0; i < 60; i++)
        {
            drone->attitude_control(HORIZ_POS|VERT_VEL|YAW_ANG|HORIZ_BODY|YAW_BODY, 0, 0, 1, 0);
            usleep(20000);
        }
        sleep(2);
        */
        
     
        //control the camera downward 
        drone->gimbal_angle_control(0, -900, 0, 20);
        sleep(2);   

        while(ros::ok())
        {
            if (tags_flag && ((fabs(tags_position_x) > 0.2) || (fabs(tags_position_y) > 0.2)))
            {
                uavClient.tagFollow(drone, yaw, tags_position_x, tags_position_y,  fly_follow_degree);
                
                tags_flag = 0;
            }

            ros::spinOnce();
            loop_rate.sleep();
        }
        
        
        /*
        // return the camera status
        drone->gimbal_angle_control(0, 0, 0, 20);
        sleep(2);
        // release control ability
        drone->release_sdk_permission_control();
        */
        
        main_operate_code = -1;
        err_flag = valid_flag = false;
    }
        
#endif

	return 0;
}
